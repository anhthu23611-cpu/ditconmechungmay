# SFA – Phân tích yêu cầu và thiết kế giao diện

## 1. Phân tích yêu cầu (từ SFA.docx)

**Người dùng:** hoạ sĩ, người đam mê vẽ, cần hình tham khảo nhưng chưa gọi tên được thứ mình cần.
**Việc chính:** chọn nhiều tag → "Tìm kiếm" → xem hình có đủ các tag đó.

### Chức năng (phạm vi nguyên mẫu, mục 2.5 và 3.3)

| # | Yêu cầu | Cách đáp ứng |
|---|---|---|
| F1 | Bảng tag chia nhóm (chủ đề, chất liệu, màu sắc, góc nhìn, địa điểm) | `tag_groups` + `tags`; thêm nhóm "Ánh sáng & thời tiết" cho đủ 6 nhóm |
| F2 | Nhóm thu gọn/mở rộng | `TagPicker`, nút `aria-expanded` |
| F3 | Ô lọc nhanh trong bảng | ô "Lọc tag trong bảng", không phân biệt dấu |
| F4 | Nút "Tìm kiếm" + trang kết quả | URL `?tags=a,b` → RPC `search_images` |
| F5 | Ô gõ chữ nhỏ có gợi ý | `QuickSuggest`: gõ → gợi ý tag → thêm vào khay đã chọn |
| F6 | Mỗi hình có dòng "Nguồn: Pinterest" | cột `source_label` + link `source_url` |
| F7 | AI gắn tag, chỉ trong danh sách chuẩn | `scripts/tag-images.ts`, lọc slug ngoài danh sách trước khi lưu |
| F8 | "Báo tag sai" trên mỗi hình | `ReportDialog` → `tag_reports`; người vận hành xem trong Supabase |

### Phi chức năng (từ tiêu chí mục 1.2)

- **Nhất quán:** cùng tag → cùng kết quả (lọc theo tag id, không theo chữ gõ). Từ đồng nghĩa ("đồng ruộng", "field") nằm ở `aliases` của một tag.
- **Không cần diễn đạt:** mọi thao tác là bấm; gõ chữ chỉ để thêm tag.
- **Mở rộng được:** thêm nhóm/tag chỉ cần thêm dòng, không đổi code.

### Quyết định thiết kế cần bạn xác nhận

1. **Nhiều tag = AND hay OR?** Tài liệu nói "hình có gắn những tag đã chọn", nên đang dùng **AND** (phải có đủ). Nhược điểm: chọn 2 màu khác nhau dễ ra 0 hình. Đã giảm bằng cách hiển thị số hình cạnh mỗi tag và làm mờ tag chưa có hình. Nếu muốn "OR trong cùng nhóm, AND giữa các nhóm" thì chỉ cần sửa hàm `search_images`.
2. **Bản quyền hình Pinterest.** Tài liệu tự nêu đây là hạn chế. Bản này chỉ lưu URL và link nguồn (không rehost). Điều khoản Pinterest hạn chế việc thu thập hàng loạt, nên cân nhắc nguồn có giấy phép (Unsplash, Pexels, Wikimedia Commons) cho bản thật.
3. **Hotlink có thể bị chặn:** nếu CDN chặn, AI không đọc được hình hoặc hình không hiện. Khi đó cần tải về Supabase Storage.
4. **Trang quản trị** để xử lý báo cáo chưa làm (cần đăng nhập). Tạm dùng Supabase Table Editor.

## 2. Thiết kế giao diện

**Hướng thiết kế:** xưởng vẽ. Nền gesso xám lạnh, mực xanh đậm, nhấn ultramarine; ba chấm màu (cadmium, ultramarine, madder) ở logo gợi 3 vệt màu pha trộn. Điểm nhớ duy nhất: chip tag ở nhóm Màu sắc mang chấm màu thật.

| Token | Giá trị | Dùng cho |
|---|---|---|
| Gesso | `#F3F4F1` | nền trang |
| Ink | `#1A2133` | chữ, nút chính |
| Ultramarine | `#2D44C4` | tag đã chọn, nút "Tìm kiếm" |
| Cadmium | `#F2B134` | viền focus, báo hiệu đã đổi tag chưa tìm |
| Madder | `#B83A4B` | "Báo tag sai", lỗi |

**Chữ:** Bricolage Grotesque (tiêu đề, tên nhóm) + Be Vietnam Pro (nội dung). Cả hai hỗ trợ đầy đủ tiếng Việt.

### Bố cục

```
Desktop (≥ 900px)
┌──────────────────────────────────────────────────────────┐
│ ●●● SFA   Gợi ý cho hoạ sĩ: chọn tag, tìm hình để vẽ.     │
├──────────────────┬───────────────────────────────────────┤
│ [Lọc tag…]       │ [Gõ để thêm tag…]       [ Tìm kiếm ]  │
│ ▾ Chủ đề    (2)  │ [Biển ×][Hoàng hôn ×]   Bỏ chọn hết   │
│  (Phong cảnh 12) │ 18 hình có đủ 2 tag đã chọn           │
│  (Chân dung 9)…  │ ┌────┐ ┌────┐ ┌────┐   masonry 3 cột  │
│ ▸ Chất liệu      │ │    │ │    │ │    │   mỗi hình:      │
│ ▸ Màu sắc        │ └────┘ └────┘ └────┘   tag, Nguồn,    │
│ ▸ Góc nhìn       │         Xem thêm        Báo tag sai   │
└──────────────────┴───────────────────────────────────────┘

Mobile (< 900px): bảng tag ẩn sau nút "Chọn tag (n)", kết quả 1–2 cột.
```

**Nguyên tắc:** bảng tag luôn nhìn thấy khi cuộn (sticky); tag đã chọn gom ở khay phía trên kết quả để bỏ nhanh; đổi tag mà chưa tìm thì nút "Tìm kiếm" viền vàng; không có hiệu ứng tự chạy.

### Trạng thái
- Chưa chọn tag: hiện "Hình mới thêm".
- 0 kết quả: "Chưa có hình nào gắn đủ các tag này", gợi ý bỏ bớt tag.
- Kho trống / lỗi kết nối: thông báo nêu việc cần làm.
- Truy cập bàn phím: tag là nút `aria-pressed`, ô gợi ý dùng ↑ ↓ Enter Esc, `prefers-reduced-motion` được tôn trọng.

## 3. Việc tiếp theo
Điền số liệu thử nghiệm mục 3.2 (độ chính xác AI): lấy 100 hình ngẫu nhiên từ `image_tags where origin = 'ai'`, kiểm tra tay, và dùng `tag_reports` làm nguồn dữ liệu sửa sai.
