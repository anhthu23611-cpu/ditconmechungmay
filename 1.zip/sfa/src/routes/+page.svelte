<script lang="ts">
  import { goto } from '$app/navigation';
  import type { PageProps } from './$types';
  import { searchImages } from '$lib/search';
  import type { ImageRow } from '$lib/types';
  import TagPicker from '$lib/components/TagPicker.svelte';
  import QuickSuggest from '$lib/components/QuickSuggest.svelte';
  import ImageCard from '$lib/components/ImageCard.svelte';
  import ReportDialog from '$lib/components/ReportDialog.svelte';

  let { data }: PageProps = $props();

  // Đang mirror URL; khi người dùng chọn tag thì ghi đè tạm, đổi URL thì tự reset.
  let selected = $derived(data.slugs);
  let images = $derived(data.first.images);
  let total = $derived(data.first.total);

  let panelOpen = $state(false);
  let loadingMore = $state(false);
  let reporting = $state<ImageRow | null>(null);

  const allTags = $derived(data.groups.flatMap((g) => g.tags.map((t) => ({ ...t, group: g.name }))));
  const bySlug = $derived(new Map(allTags.map((t) => [t.slug, t])));
  const dirty = $derived(selected.join(',') !== data.slugs.join(','));

  function toggle(slug: string) {
    selected = selected.includes(slug) ? selected.filter((s) => s !== slug) : [...selected, slug];
  }
  function add(slug: string) {
    if (!selected.includes(slug)) selected = [...selected, slug];
  }
  function search() {
    panelOpen = false;
    goto(selected.length ? `/?tags=${selected.join(',')}` : '/', { keepFocus: true });
  }
  async function loadMore() {
    loadingMore = true;
    try {
      const next = await searchImages(data.slugs, images.length);
      images = [...images, ...next.images];
    } finally {
      loadingMore = false;
    }
  }
</script>

<main class="wrap shell">
  <aside class="panel" class:open={panelOpen}>
    <TagPicker groups={data.groups} {selected} ontoggle={toggle} />
  </aside>

  <section class="results" aria-live="polite">
    <div class="toolbar">
      <button type="button" class="btn ghost toggle" onclick={() => (panelOpen = !panelOpen)} aria-expanded={panelOpen}>
        {panelOpen ? 'Ẩn bảng tag' : 'Chọn tag'}{selected.length ? ` (${selected.length})` : ''}
      </button>
      <QuickSuggest options={allTags} {selected} onpick={add} />
      <button type="button" class="btn primary go" class:dirty onclick={search}>Tìm kiếm</button>
    </div>

    {#if selected.length}
      <ul class="tray" aria-label="Tag đã chọn">
        {#each selected as slug (slug)}
          {@const t = bySlug.get(slug)}
          <li>
            <button type="button" onclick={() => toggle(slug)} aria-label="Bỏ tag {t?.name ?? slug}">
              {#if t?.swatch}<i style:background={t.swatch}></i>{/if}
              {t?.name ?? slug}
              <span aria-hidden="true">×</span>
            </button>
          </li>
        {/each}
        <li><button type="button" class="clear" onclick={() => { selected = []; search(); }}>Bỏ chọn hết</button></li>
      </ul>
    {/if}

    <h1 class="count">
      {#if data.slugs.length === 0}
        Hình mới thêm
      {:else}
        {total} hình có đủ {data.slugs.length} tag đã chọn
      {/if}
    </h1>

    {#if dirty}
      <p class="stale">Bạn đã đổi tag. Bấm "Tìm kiếm" để cập nhật kết quả.</p>
    {/if}

    {#if images.length}
      <div class="grid">
        {#each images as image (image.id)}
          <ImageCard {image} onreport={(img) => (reporting = img)} />
        {/each}
      </div>
      {#if images.length < total}
        <div class="more">
          <button type="button" class="btn ghost" onclick={loadMore} disabled={loadingMore}>
            {loadingMore ? 'Đang tải' : `Xem thêm (${total - images.length} hình)`}
          </button>
        </div>
      {/if}
    {:else if data.slugs.length}
      <div class="empty">
        <h2>Chưa có hình nào gắn đủ các tag này</h2>
        <p>Bỏ bớt một tag để mở rộng kết quả, hoặc chọn tag cùng nhóm khác.</p>
      </div>
    {:else}
      <div class="empty">
        <h2>Kho hình đang trống</h2>
        <p>Thêm hình bằng <code>npm run import</code>, rồi gắn tag bằng <code>npm run tag</code>.</p>
      </div>
    {/if}
  </section>
</main>

{#if reporting}
  <ReportDialog image={reporting} ondone={() => (reporting = null)} />
{/if}

<style>
  .shell { display: grid; grid-template-columns: minmax(280px, 340px) minmax(0, 1fr); gap: 2rem; padding-block: 1.5rem 4rem; align-items: start; }
  .panel {
    position: sticky; top: 1rem; max-height: calc(100vh - 2rem); overflow: auto;
    background: var(--paper); border: 1px solid var(--line); border-radius: var(--r-panel); padding: 1rem 1.1rem;
  }
  .toolbar { display: flex; flex-wrap: wrap; gap: 0.6rem; align-items: center; }
  .toggle { display: none; }
  .go.dirty { box-shadow: 0 0 0 3px var(--cadmium); }
  .tray { list-style: none; padding: 0; margin: 1rem 0 0; display: flex; flex-wrap: wrap; gap: 0.4rem; }
  .tray button {
    display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.3rem 0.7rem;
    border: 0; border-radius: var(--r-chip); background: var(--ultramarine); color: #fff; font-size: 0.9rem;
  }
  .tray i { width: 0.75rem; height: 0.75rem; border-radius: 50%; box-shadow: 0 0 0 2px #fff; }
  .tray .clear { background: none; color: var(--ink-soft); text-decoration: underline; padding-inline: 0.3rem; }
  .count { font-size: 1.6rem; margin: 1.5rem 0 0.75rem; }
  .stale { margin: 0 0 1rem; color: var(--ink-soft); }
  .grid { columns: 3 220px; column-gap: 1rem; }
  .more { display: flex; justify-content: center; padding-top: 1rem; }
  .empty { padding: 3rem 0; max-width: 32rem; }
  .empty h2 { font-size: 1.3rem; margin-bottom: 0.5rem; }
  .empty p { color: var(--ink-soft); margin: 0; }

  @media (max-width: 900px) {
    .shell { grid-template-columns: 1fr; gap: 1rem; }
    .panel { position: static; max-height: none; display: none; }
    .panel.open { display: block; }
    .toggle { display: inline-block; }
  }
</style>
