<script lang="ts">
  import '../app.css';
  let { children } = $props();
</script>

<svelte:head>
  <title>SFA · Gợi ý cho hoạ sĩ</title>
  <meta name="description" content="Chọn tag thay vì gõ chữ để tìm hình tham khảo cho tranh của bạn." />
  <link rel="icon" href="/favicon.svg" />
</svelte:head>

<header class="top">
  <div class="wrap bar">
    <a class="brand" href="/" aria-label="SFA, về trang chủ">
      <span class="mark" aria-hidden="true"><i></i><i></i><i></i></span>
      <span class="word">SFA</span>
    </a>
    <p class="tagline">Gợi ý cho hoạ sĩ: chọn tag, tìm hình để vẽ.</p>
  </div>
</header>

{@render children()}

<style>
  .top { border-bottom: 1px solid var(--line); background: var(--paper); }
  .bar { display: flex; align-items: center; gap: 1.25rem; padding-block: 0.75rem; }
  .brand { display: inline-flex; align-items: center; gap: 0.6rem; text-decoration: none; color: var(--ink); }
  .word { font: 700 1.5rem/1 var(--font-display); letter-spacing: 0.02em; }
  .mark { display: inline-flex; }
  .mark i { width: 14px; height: 14px; border-radius: 50%; margin-right: -4px; mix-blend-mode: multiply; }
  .mark i:nth-child(1) { background: var(--cadmium); }
  .mark i:nth-child(2) { background: var(--ultramarine); }
  .mark i:nth-child(3) { background: var(--madder); }
  .tagline { margin: 0; color: var(--ink-soft); font-size: 0.9rem; }
  @media (max-width: 640px) { .tagline { display: none; } }
</style>
