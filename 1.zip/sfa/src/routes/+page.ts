import { parseSlugs } from '$lib/text';
import { searchImages } from '$lib/search';
import { error } from '@sveltejs/kit';
import type { PageLoad } from './$types';

export const load: PageLoad = async ({ url }) => {
  const slugs = parseSlugs(url.searchParams.get('tags'));
  try {
    return { slugs, first: await searchImages(slugs) };
  } catch (e) {
    console.error(e);
    error(500, 'Tìm kiếm thất bại. Kiểm tra hàm search_images trong Supabase.');
  }
};
