<script lang="ts">
  import { page } from '$app/state';
</script>

<main class="wrap">
  <h1>Có lỗi xảy ra</h1>
  <p>{page.error?.message}</p>
  <p><a href="/">Về trang chủ</a></p>
</main>

<style>
  main { padding: 4rem 0; max-width: 40rem; }
</style>
