import { error } from '@sveltejs/kit';
import { supabase } from '$lib/supabase';
import type { TagGroup } from '$lib/types';
import type { LayoutLoad } from './$types';

export const load: LayoutLoad = async () => {
  const [groupsRes, countsRes] = await Promise.all([
    supabase
      .from('tag_groups')
      .select('id, slug, name, sort_order, tags(id, slug, name, aliases, swatch, sort_order)')
      .order('sort_order')
      .order('sort_order', { referencedTable: 'tags' }),
    supabase.from('tag_counts').select('tag_id, image_count')
  ]);

  if (groupsRes.error || countsRes.error) {
    console.error(groupsRes.error ?? countsRes.error);
    error(500, 'Không tải được bảng tag từ Supabase. Kiểm tra .env và đã chạy migration.sql + seed.sql chưa.');
  }

  const counts = new Map(countsRes.data.map((c) => [c.tag_id, c.image_count]));
  const groups: TagGroup[] = (groupsRes.data ?? []).map((g) => ({
    ...g,
    tags: g.tags.map((t) => ({ ...t, image_count: counts.get(t.id) ?? 0 }))
  }));

  return { groups };
};
