<script lang="ts">
  import type { TagGroup } from '$lib/types';
  import { matches } from '$lib/text';

  let {
    groups,
    selected,
    ontoggle
  }: { groups: TagGroup[]; selected: string[]; ontoggle: (slug: string) => void } = $props();

  let query = $state('');
  let openState = $state<Record<string, boolean>>({});

  const visible = $derived(
    groups
      .map((g, i) => ({
        group: g,
        tags: query ? g.tags.filter((t) => matches(query, [t.name, ...t.aliases])) : g.tags,
        open: query ? true : (openState[g.slug] ?? i === 0),
        picked: g.tags.filter((t) => selected.includes(t.slug)).length
      }))
      .filter((v) => v.tags.length > 0)
  );
</script>

<section class="picker" aria-label="Bảng chọn tag">
  <div class="filter">
    <label class="sr-only" for="tag-filter">Lọc tag trong bảng</label>
    <input id="tag-filter" type="search" placeholder="Lọc tag trong bảng" bind:value={query} autocomplete="off" />
  </div>

  {#each visible as v (v.group.slug)}
    <div class="group">
      <h2>
        <button
          type="button"
          class="head"
          aria-expanded={v.open}
          aria-controls="grp-{v.group.slug}"
          onclick={() => (openState[v.group.slug] = !v.open)}
        >
          <span>{v.group.name}</span>
          {#if v.picked}<span class="badge" aria-label="{v.picked} tag đã chọn">{v.picked}</span>{/if}
          <svg class="chev" class:open={v.open} viewBox="0 0 12 12" width="12" height="12" aria-hidden="true">
            <path d="M2 4.5 6 8.5 10 4.5" fill="none" stroke="currentColor" stroke-width="1.6" />
          </svg>
        </button>
      </h2>
      {#if v.open}
        <ul id="grp-{v.group.slug}" class="chips">
          {#each v.tags as t (t.slug)}
            {@const on = selected.includes(t.slug)}
            <li>
              <button
                type="button"
                class="chip"
                class:on
                class:empty={t.image_count === 0 && !on}
                aria-pressed={on}
                onclick={() => ontoggle(t.slug)}
              >
                {#if t.swatch}<i class="dot" style:background={t.swatch}></i>{/if}
                <span>{t.name}</span>
                <small>{t.image_count}</small>
              </button>
            </li>
          {/each}
        </ul>
      {/if}
    </div>
  {:else}
    <p class="none">Không có tag nào khớp "{query}".</p>
  {/each}
</section>

<style>
  .picker { display: flex; flex-direction: column; gap: 0.25rem; }
  .filter { position: sticky; top: 0; background: var(--paper); padding-bottom: 0.5rem; z-index: 1; }
  input[type='search'] {
    width: 100%; padding: 0.55rem 0.9rem; border-radius: var(--r-chip);
    border: 1px solid var(--line); background: var(--gesso);
  }
  .group { border-top: 1px solid var(--line); }
  .head {
    width: 100%; display: flex; align-items: center; gap: 0.5rem;
    padding: 0.75rem 0; background: none; border: 0;
    font: 600 1.05rem/1.2 var(--font-display); text-align: left;
  }
  .head span:first-child { flex: 1; }
  .badge {
    background: var(--ultramarine); color: #fff; font: 500 0.75rem/1 var(--font-body);
    min-width: 1.4rem; padding: 0.3rem 0.45rem; border-radius: var(--r-chip); text-align: center;
  }
  .chev { transition: transform 0.15s; color: var(--ink-soft); }
  .chev.open { transform: rotate(180deg); }
  .chips { list-style: none; margin: 0; padding: 0 0 0.9rem; display: flex; flex-wrap: wrap; gap: 0.4rem; }
  .chip {
    display: inline-flex; align-items: center; gap: 0.4rem;
    padding: 0.35rem 0.75rem; border-radius: var(--r-chip);
    border: 1px solid var(--line); background: var(--paper); font-size: 0.9rem;
    transition: background 0.12s, color 0.12s, border-color 0.12s;
  }
  .chip:hover { border-color: var(--ultramarine); }
  .chip small { color: var(--ink-soft); font-size: 0.72rem; }
  .chip.on { background: var(--ultramarine); border-color: var(--ultramarine); color: #fff; }
  .chip.on small { color: #d7dcff; }
  .chip.empty { opacity: 0.45; }
  .dot { width: 0.8rem; height: 0.8rem; border-radius: 50%; box-shadow: inset 0 0 0 1px rgb(0 0 0 / 0.18); }
  .chip.on .dot { box-shadow: 0 0 0 2px #fff; }
  .none { color: var(--ink-soft); padding: 1rem 0; margin: 0; }
</style>
