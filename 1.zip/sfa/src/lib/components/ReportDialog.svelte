<script lang="ts">
  import { supabase } from '$lib/supabase';
  import type { ImageRow } from '$lib/types';

  let { image, ondone }: { image: ImageRow; ondone: () => void } = $props();

  let dialog = $state<HTMLDialogElement>();
  let picked = $state<number[]>([]);
  let note = $state('');
  let status = $state<'idle' | 'sending' | 'done' | 'error'>('idle');

  $effect(() => {
    dialog?.showModal();
  });

  function toggle(id: number) {
    picked = picked.includes(id) ? picked.filter((x) => x !== id) : [...picked, id];
  }

  async function submit(e: SubmitEvent) {
    e.preventDefault();
    const text = note.trim();
    if (!picked.length && !text) return;
    status = 'sending';
    const rows = picked.length
      ? picked.map((tag_id) => ({ image_id: image.id, tag_id, note: text || null }))
      : [{ image_id: image.id, tag_id: null, note: text }];
    const { error } = await supabase.from('tag_reports').insert(rows);
    status = error ? 'error' : 'done';
  }
</script>

<dialog bind:this={dialog} onclose={ondone} aria-labelledby="rp-title">
  <form onsubmit={submit}>
    <h2 id="rp-title">Báo tag sai</h2>

    {#if status === 'done'}
      <p class="ok">Đã gửi báo cáo. Người vận hành sẽ xem lại hình này.</p>
      <div class="row"><button type="button" class="btn primary" onclick={() => dialog?.close()}>Đóng</button></div>
    {:else}
      <p class="hint">Chọn tag không đúng với hình, hoặc mô tả tag còn thiếu.</p>
      <fieldset>
        <legend class="sr-only">Tag không đúng</legend>
        {#each image.tags as t (t.id)}
          <label class="opt">
            <input type="checkbox" checked={picked.includes(t.id)} onchange={() => toggle(t.id)} />
            {t.name}
          </label>
        {/each}
      </fieldset>
      <label class="note">
        <span>Ghi chú (không bắt buộc nếu đã chọn tag)</span>
        <textarea rows="3" maxlength="500" bind:value={note} placeholder="Ví dụ: hình này là sơn dầu, không phải màu nước"></textarea>
      </label>
      {#if status === 'error'}<p class="err">Gửi không được. Thử lại sau một lúc.</p>{/if}
      <div class="row">
        <button type="button" class="btn ghost" onclick={() => dialog?.close()}>Huỷ</button>
        <button type="submit" class="btn primary" disabled={status === 'sending' || (!picked.length && !note.trim())}>
          {status === 'sending' ? 'Đang gửi' : 'Gửi báo cáo'}
        </button>
      </div>
    {/if}
  </form>
</dialog>

<style>
  dialog {
    border: 0; border-radius: var(--r-panel); padding: 0; width: min(28rem, 92vw);
    background: var(--paper); color: var(--ink); box-shadow: 0 20px 60px rgb(26 33 51 / 0.3);
  }
  dialog::backdrop { background: rgb(26 33 51 / 0.45); }
  form { padding: 1.5rem; display: grid; gap: 1rem; }
  fieldset { border: 0; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: 0.4rem; }
  .opt {
    display: inline-flex; gap: 0.4rem; align-items: center; padding: 0.3rem 0.7rem;
    border: 1px solid var(--line); border-radius: var(--r-chip); font-size: 0.9rem;
  }
  .note { display: grid; gap: 0.3rem; font-size: 0.9rem; }
  textarea { padding: 0.6rem 0.75rem; border: 1px solid var(--line); border-radius: 8px; resize: vertical; }
  .row { display: flex; justify-content: flex-end; gap: 0.5rem; }
  .hint { margin: 0; color: var(--ink-soft); }
  .ok { margin: 0; }
  .err { margin: 0; color: var(--madder); }
</style>
