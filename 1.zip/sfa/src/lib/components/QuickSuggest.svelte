<script lang="ts">
  import type { Tag } from '$lib/types';
  import { matches } from '$lib/text';

  type Option = Tag & { group: string };
  let {
    options,
    selected,
    onpick
  }: { options: Option[]; selected: string[]; onpick: (slug: string) => void } = $props();

  let text = $state('');
  let focused = $state(false);
  let active = $state(0);

  const results = $derived(
    text.trim()
      ? options.filter((t) => !selected.includes(t.slug) && matches(text, [t.name, ...t.aliases])).slice(0, 6)
      : []
  );
  const open = $derived(focused && text.trim().length > 0);

  $effect(() => {
    text;
    active = 0;
  });

  function pick(o: Option) {
    onpick(o.slug);
    text = '';
  }

  function onkeydown(e: KeyboardEvent) {
    if (e.key === 'ArrowDown') { e.preventDefault(); active = Math.min(active + 1, results.length - 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(active - 1, 0); }
    else if (e.key === 'Enter' && open && results[active]) { e.preventDefault(); pick(results[active]); }
    else if (e.key === 'Escape') { text = ''; }
  }
</script>

<div class="suggest">
  <label class="sr-only" for="quick">Gõ để thêm tag</label>
  <input
    id="quick"
    type="text"
    role="combobox"
    aria-expanded={open}
    aria-controls="quick-list"
    aria-autocomplete="list"
    aria-activedescendant={open && results[active] ? `opt-${results[active].slug}` : undefined}
    placeholder="Gõ để thêm tag, ví dụ: biển"
    autocomplete="off"
    bind:value={text}
    onfocus={() => (focused = true)}
    onblur={() => (focused = false)}
    {onkeydown}
  />
  {#if open}
    <ul id="quick-list" role="listbox">
      {#each results as o, i (o.slug)}
        <!-- svelte-ignore a11y_click_events_have_key_events -->
        <li
          id="opt-{o.slug}"
          role="option"
          aria-selected={i === active}
          class:active={i === active}
          onmousedown={(e) => { e.preventDefault(); pick(o); }}
        >
          <span>{o.name}</span><small>{o.group}</small>
        </li>
      {:else}
        <li class="none" role="option" aria-selected="false">Chưa có tag "{text}". Thử duyệt bảng tag.</li>
      {/each}
    </ul>
  {/if}
</div>

<style>
  .suggest { position: relative; flex: 1; min-width: 14rem; max-width: 22rem; }
  input {
    width: 100%; padding: 0.55rem 0.9rem; border-radius: var(--r-chip);
    border: 1px solid var(--line); background: var(--paper);
  }
  ul {
    position: absolute; inset-inline: 0; top: calc(100% + 4px); z-index: 5;
    list-style: none; margin: 0; padding: 0.25rem; background: var(--paper);
    border: 1px solid var(--line); border-radius: 10px; box-shadow: 0 8px 24px rgb(26 33 51 / 0.12);
  }
  li { display: flex; justify-content: space-between; gap: 1rem; padding: 0.5rem 0.7rem; border-radius: 6px; cursor: pointer; }
  li.active { background: var(--gesso); }
  li small { color: var(--ink-soft); }
  li.none { color: var(--ink-soft); cursor: default; }
</style>
