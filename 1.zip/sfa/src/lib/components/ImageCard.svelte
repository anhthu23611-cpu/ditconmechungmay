<script lang="ts">
  import type { ImageRow } from '$lib/types';

  let { image, onreport }: { image: ImageRow; onreport: (img: ImageRow) => void } = $props();
  const shown = $derived(image.tags.slice(0, 5));
  const rest = $derived(image.tags.length - shown.length);
</script>

<figure class="card">
  <img
    src={image.url}
    alt={image.tags.length ? image.tags.map((t) => t.name).join(', ') : 'Hình tham khảo'}
    width={image.width ?? undefined}
    height={image.height ?? undefined}
    loading="lazy"
    decoding="async"
    referrerpolicy="no-referrer"
  />
  <figcaption>
    {#if shown.length}
      <ul>
        {#each shown as t (t.id)}<li>{t.name}</li>{/each}
        {#if rest > 0}<li class="more">+{rest}</li>{/if}
      </ul>
    {/if}
    <div class="meta">
      {#if image.source_url}
        <a href={image.source_url} target="_blank" rel="noopener noreferrer">{image.source_label}</a>
      {:else}
        <span>{image.source_label}</span>
      {/if}
      <button type="button" onclick={() => onreport(image)}>Báo tag sai</button>
    </div>
  </figcaption>
</figure>

<style>
  .card {
    margin: 0 0 1rem; break-inside: avoid; background: var(--paper);
    border-radius: var(--r-card); overflow: hidden; border: 1px solid var(--line);
  }
  img { width: 100%; background: #e6e8e1; }
  figcaption { padding: 0.6rem 0.75rem 0.7rem; display: grid; gap: 0.45rem; }
  ul { list-style: none; margin: 0; padding: 0; display: flex; flex-wrap: wrap; gap: 0.3rem; }
  li { font-size: 0.75rem; padding: 0.1rem 0.5rem; border-radius: var(--r-chip); background: var(--gesso); color: var(--ink-soft); }
  .meta { display: flex; justify-content: space-between; align-items: center; font-size: 0.78rem; color: var(--ink-soft); }
  .meta a { color: var(--ink-soft); }
  .meta button { background: none; border: 0; padding: 0; color: var(--madder); text-decoration: underline; text-underline-offset: 2px; }
</style>
