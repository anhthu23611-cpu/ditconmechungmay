export type Tag = {
  id: number;
  slug: string;
  name: string;
  aliases: string[];
  swatch: string | null;
  sort_order: number;
  image_count: number;
};

export type TagGroup = {
  id: number;
  slug: string;
  name: string;
  sort_order: number;
  tags: Tag[];
};

export type ImageTag = { id: number; slug: string; name: string };

export type ImageRow = {
  id: string;
  url: string;
  source_label: string;
  source_url: string | null;
  width: number | null;
  height: number | null;
  tags: ImageTag[];
};

export type SearchPage = { images: ImageRow[]; total: number };
