import { createClient } from '@supabase/supabase-js';
import { env } from '$env/dynamic/public';

const url = env.PUBLIC_SUPABASE_URL;
const key = env.PUBLIC_SUPABASE_ANON_KEY;

if (!url || !key) {
  throw new Error('Thiếu PUBLIC_SUPABASE_URL hoặc PUBLIC_SUPABASE_ANON_KEY. Sao chép .env.example thành .env và điền giá trị.');
}

// Chỉ dùng anon key ở đây. Quyền đọc/ghi được giới hạn bởi RLS trong migration.sql.
export const supabase = createClient(url, key, { auth: { persistSession: false } });
