/** Bỏ dấu tiếng Việt + chữ thường, để "dong que" khớp "Đồng quê". */
export function normalize(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/gi, 'd')
    .toLowerCase()
    .trim();
}

/** true nếu query khớp một trong các chuỗi (tên tag, từ đồng nghĩa). */
export function matches(query: string, haystacks: string[]): boolean {
  const q = normalize(query);
  return !q || haystacks.some((h) => normalize(h).includes(q));
}

export function parseSlugs(param: string | null): string[] {
  if (!param) return [];
  return [...new Set(param.split(',').map((s) => s.trim()).filter((s) => /^[a-z0-9-]+$/.test(s)))];
}
