import { supabase } from '$lib/supabase';
import type { ImageRow, SearchPage } from '$lib/types';

export const PAGE_SIZE = 24;

export async function searchImages(slugs: string[], offset = 0, limit = PAGE_SIZE): Promise<SearchPage> {
  const { data, error } = await supabase.rpc('search_images', {
    tag_slugs: slugs,
    page_limit: limit,
    page_offset: offset
  });
  if (error) throw error;
  const rows = (data ?? []) as (ImageRow & { total_count: number })[];
  return {
    images: rows.map(({ total_count: _t, ...img }) => img),
    total: Number(rows[0]?.total_count ?? 0)
  };
}
