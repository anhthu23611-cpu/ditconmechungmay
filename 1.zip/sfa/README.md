# SFA – Suggestions for Artists

Chọn tag thay vì gõ chữ để tìm hình tham khảo. SvelteKit (Svelte 5) + Supabase.

## Chạy lần đầu

1. Tạo project tại supabase.com.
2. Vào **SQL Editor**, chạy lần lượt `supabase/migration.sql` rồi `supabase/seed.sql`.
3. `cp .env.example .env` và điền `PUBLIC_SUPABASE_URL`, `PUBLIC_SUPABASE_ANON_KEY`
   (Project Settings → API). `SUPABASE_SERVICE_ROLE_KEY` và `ANTHROPIC_API_KEY` chỉ cần cho bước 5.
4. `npm install` rồi `npm run dev` → http://localhost:5173
5. Nạp hình và gắn tag:
   - điền `data/images.json`, chạy `npm run import`
   - chạy `npm run tag` (AI gắn tag, chỉ trong danh sách chuẩn)

## Cấu trúc

| Đường dẫn | Vai trò |
|---|---|
| `supabase/migration.sql` | bảng, view `tag_counts`, hàm `search_images`, RLS |
| `supabase/seed.sql` | 6 nhóm tag chuẩn, 53 tag, từ đồng nghĩa |
| `src/lib/supabase.ts` | client dùng anon key |
| `src/routes/+layout.ts` | tải nhóm tag + số hình mỗi tag |
| `src/routes/+page.ts` | đọc `?tags=a,b` từ URL, gọi `search_images` |
| `src/lib/components/` | TagPicker, QuickSuggest, ImageCard, ReportDialog |
| `scripts/` | nhập hình, AI gắn tag (chạy trên máy, dùng service_role) |
| `docs/PHAN-TICH-THIET-KE.md` | phân tích yêu cầu và thiết kế giao diện |

## Bảo mật

- Trình duyệt chỉ có anon key. RLS cho phép đọc, và chỉ cho **thêm** báo cáo tag sai.
- `service_role` key không bao giờ đưa vào `src/`.
- Xem báo cáo: Supabase → Table Editor → `tag_reports` (status = open). Trang quản trị cần đăng nhập, chưa làm ở bản này.
