-- Danh sách tag chuẩn (6 nhóm). AI chỉ được chọn trong danh sách này.
insert into tag_groups (slug, name, sort_order) values
  ('chu-de',    'Chủ đề',               1),
  ('chat-lieu', 'Chất liệu',            2),
  ('mau-sac',   'Màu sắc',              3),
  ('goc-nhin',  'Góc nhìn',             4),
  ('dia-diem',  'Địa điểm',             5),
  ('anh-sang',  'Ánh sáng & thời tiết', 6);

insert into tags (group_id, slug, name, aliases, swatch, sort_order)
select g.id, v.slug, v.name, v.aliases, v.swatch, v.ord
from (values
  ('chu-de','phong-canh','Phong cảnh',array['landscape','cảnh vật'],null,1),
  ('chu-de','chan-dung','Chân dung',array['portrait','khuôn mặt'],null,2),
  ('chu-de','dang-nguoi','Dáng người',array['figure','tư thế','pose'],null,3),
  ('chu-de','dong-vat','Động vật',array['animal','thú'],null,4),
  ('chu-de','hoa-la','Hoa lá',array['hoa','cây cối','botanical'],null,5),
  ('chu-de','kien-truc','Kiến trúc',array['nhà cửa','building'],null,6),
  ('chu-de','tinh-vat','Tĩnh vật',array['still life'],null,7),
  ('chu-de','do-an','Đồ ăn',array['thức ăn','food'],null,8),
  ('chu-de','xe-co','Xe cộ',array['phương tiện','vehicle'],null,9),
  ('chu-de','gia-tuong','Giả tưởng',array['fantasy','huyền ảo'],null,10),

  ('chat-lieu','mau-nuoc','Màu nước',array['watercolor'],null,1),
  ('chat-lieu','son-dau','Sơn dầu',array['oil painting'],null,2),
  ('chat-lieu','acrylic','Acrylic',array['sơn acrylic'],null,3),
  ('chat-lieu','chi-than','Chì / Than',array['pencil','charcoal','bút chì'],null,4),
  ('chat-lieu','muc','Mực',array['ink','bút mực'],null,5),
  ('chat-lieu','pastel','Pastel',array['phấn màu'],null,6),
  ('chat-lieu','ky-thuat-so','Kỹ thuật số',array['digital','vẽ máy'],null,7),
  ('chat-lieu','anh-chup','Ảnh chụp',array['photo','photograph'],null,8),

  ('mau-sac','do','Đỏ',array['red'],'#C8372D',1),
  ('mau-sac','cam','Cam',array['orange'],'#E8833A',2),
  ('mau-sac','vang','Vàng',array['yellow'],'#F2C230',3),
  ('mau-sac','xanh-la','Xanh lá',array['green','lục'],'#4F9D5D',4),
  ('mau-sac','xanh-duong','Xanh dương',array['blue','lam'],'#2F6FB5',5),
  ('mau-sac','tim','Tím',array['purple'],'#7A4FA3',6),
  ('mau-sac','hong','Hồng',array['pink'],'#E58FAE',7),
  ('mau-sac','nau','Nâu',array['brown'],'#7A5230',8),
  ('mau-sac','don-sac','Đơn sắc',array['đen trắng','monochrome'],'#8A8F98',9),
  ('mau-sac','tong-am','Tông ấm',array['warm'],'#D9822B',10),
  ('mau-sac','tong-lanh','Tông lạnh',array['cool'],'#4A86B8',11),

  ('goc-nhin','chinh-dien','Chính diện',array['front','nhìn thẳng'],null,1),
  ('goc-nhin','nghieng','Nghiêng 3/4',array['three quarter','góc nghiêng'],null,2),
  ('goc-nhin','tu-tren','Nhìn từ trên',array['top view','bird eye','từ trên xuống'],null,3),
  ('goc-nhin','tu-duoi','Nhìn từ dưới',array['low angle','từ dưới lên'],null,4),
  ('goc-nhin','tu-sau','Nhìn từ sau',array['back view','phía sau'],null,5),
  ('goc-nhin','can-canh','Cận cảnh',array['close up'],null,6),
  ('goc-nhin','toan-canh','Toàn cảnh',array['wide','panorama'],null,7),

  ('dia-diem','bien','Biển',array['sea','beach','bãi biển'],null,1),
  ('dia-diem','nui','Núi',array['mountain','đồi'],null,2),
  ('dia-diem','rung','Rừng',array['forest','cây rừng'],null,3),
  ('dia-diem','dong-que','Đồng quê',array['cánh đồng','đồng ruộng','field','nông thôn'],null,4),
  ('dia-diem','song-ho','Sông hồ',array['river','lake','sông','hồ'],null,5),
  ('dia-diem','thanh-pho','Thành phố',array['city','đô thị'],null,6),
  ('dia-diem','pho-co','Phố cổ',array['old town','hẻm'],null,7),
  ('dia-diem','cho','Chợ',array['market'],null,8),
  ('dia-diem','vuon','Vườn',array['garden','công viên'],null,9),
  ('dia-diem','trong-nha','Trong nhà',array['indoor','nội thất'],null,10),

  ('anh-sang','binh-minh','Bình minh',array['sunrise','sáng sớm'],null,1),
  ('anh-sang','ngay-nang','Ngày nắng',array['sunny','nắng'],null,2),
  ('anh-sang','hoang-hon','Hoàng hôn',array['sunset','chiều tà'],null,3),
  ('anh-sang','ban-dem','Ban đêm',array['night','đêm'],null,4),
  ('anh-sang','nguoc-sang','Ngược sáng',array['backlight','silhouette'],null,5),
  ('anh-sang','suong-mu','Sương mù',array['fog','mist'],null,6),
  ('anh-sang','mua','Mưa',array['rain','trời mưa'],null,7)
) as v(group_slug, slug, name, aliases, swatch, ord)
join tag_groups g on g.slug = v.group_slug;
