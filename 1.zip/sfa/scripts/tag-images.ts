// AI gắn tag cho các hình có tag_status = 'pending'. AI CHỈ được chọn slug trong bảng `tags`.
// Chạy: npm run tag   (đặt TAG_MODEL trong .env nếu muốn đổi model)
import Anthropic from '@anthropic-ai/sdk';
import { createClient } from '@supabase/supabase-js';

const MODEL = process.env.TAG_MODEL ?? 'claude-haiku-5-5';
const MIN_CONFIDENCE = 0.6;
const CONCURRENCY = 4;

const sb = createClient(process.env.PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: { persistSession: false }
});
const ai = new Anthropic();

const { data: tagRows, error: tagErr } = await sb
  .from('tags')
  .select('id, slug, name, tag_groups(name)')
  .order('group_id')
  .order('sort_order');
if (tagErr) throw tagErr;

const idBySlug = new Map(tagRows!.map((t) => [t.slug as string, t.id as number]));
const byGroup = new Map<string, string[]>();
for (const t of tagRows as any[]) {
  const g = t.tag_groups?.name ?? 'Khác';
  byGroup.set(g, [...(byGroup.get(g) ?? []), `${t.slug} (${t.name})`]);
}
const vocabulary = [...byGroup].map(([g, items]) => `${g}: ${items.join(', ')}`).join('\n');

const system = `Bạn gắn tag cho kho hình tham khảo của hoạ sĩ.
Chỉ được chọn slug trong danh sách dưới đây, không tự tạo tag mới.
Chọn mọi tag thực sự áp dụng được cho hình (thường 4 đến 10 tag, ít nhất 1 tag mỗi nhóm nếu rõ ràng).
Chỉ trả về JSON, không kèm giải thích: {"tags":[{"slug":"...","confidence":0.0}]}

Danh sách tag:
${vocabulary}`;

async function tagOne(img: { id: string; url: string }) {
  try {
    const res = await ai.messages.create({
      model: MODEL,
      max_tokens: 600,
      system,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'url', url: img.url } },
            { type: 'text', text: 'Gắn tag cho hình này.' }
          ]
        }
      ]
    });
    const text = res.content.map((b) => (b.type === 'text' ? b.text : '')).join('');
    const parsed = JSON.parse(text.match(/\{[\s\S]*\}/)?.[0] ?? '{}') as { tags?: { slug: string; confidence?: number }[] };

    const rows = (parsed.tags ?? [])
      .filter((t) => idBySlug.has(t.slug) && (t.confidence ?? 1) >= MIN_CONFIDENCE) // loại slug ngoài danh sách
      .map((t) => ({ image_id: img.id, tag_id: idBySlug.get(t.slug)!, origin: 'ai', confidence: t.confidence ?? null }));

    if (rows.length) {
      const { error } = await sb.from('image_tags').upsert(rows, { onConflict: 'image_id,tag_id', ignoreDuplicates: true });
      if (error) throw error;
    }
    await sb.from('images').update({ tag_status: rows.length ? 'tagged' : 'failed' }).eq('id', img.id);
    console.log(`✓ ${img.id} → ${rows.length} tag`);
  } catch (e) {
    console.error(`✗ ${img.id}`, (e as Error).message);
    await sb.from('images').update({ tag_status: 'failed' }).eq('id', img.id);
  }
}

while (true) {
  const { data: batch, error } = await sb.from('images').select('id, url').eq('tag_status', 'pending').limit(CONCURRENCY * 5);
  if (error) throw error;
  if (!batch?.length) break;
  for (let i = 0; i < batch.length; i += CONCURRENCY) {
    await Promise.all(batch.slice(i, i + CONCURRENCY).map(tagOne));
  }
}
console.log('Xong. Hình lỗi có tag_status = failed, chạy lại bằng cách đặt về pending.');
