// Nhập danh sách hình vào Supabase. Chỉ lưu URL + link nguồn, không tải hình về.
// Dùng: điền data/images.json rồi chạy `npm run import`.
// Định dạng: [{ "url": "...", "source_url": "https://www.pinterest.com/pin/...", "width": 736, "height": 1104 }]
import { createClient } from '@supabase/supabase-js';
import { readFile } from 'node:fs/promises';

const sb = createClient(process.env.PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: { persistSession: false }
});

const items: { url: string; source_url?: string; width?: number; height?: number }[] = JSON.parse(
  await readFile(new URL('../data/images.json', import.meta.url), 'utf8')
);

const rows = items.map((i) => ({
  url: i.url,
  source_url: i.source_url ?? null,
  width: i.width ?? null,
  height: i.height ?? null,
  source_label: 'Nguồn: Pinterest'
}));

for (let i = 0; i < rows.length; i += 200) {
  const { error } = await sb.from('images').upsert(rows.slice(i, i + 200), { onConflict: 'url', ignoreDuplicates: true });
  if (error) throw error;
}
console.log(`Đã nhập ${rows.length} hình.`);
