// Tải ảnh trong data/images/ lên Supabase Storage và ghi vào bảng images.
// Dùng: npm run import   (chạy lại nhiều lần được, ảnh đã có sẽ bỏ qua)
import { createClient } from '@supabase/supabase-js';
import { readFile } from 'node:fs/promises';

const BUCKET = 'images';
const sb = createClient(process.env.PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: { persistSession: false }
});

type Item = { file: string; width: number; height: number; file_size: number; sha256: string; source_url: string | null };
const manifest: Item[] = JSON.parse(await readFile(new URL('../data/images.json', import.meta.url), 'utf8'));

const { data: existing, error: exErr } = await sb.from('images').select('file_name');
if (exErr) throw exErr;
const have = new Set((existing ?? []).map((r) => r.file_name));

let added = 0;
for (const m of manifest) {
  if (have.has(m.file)) continue;
  const body = await readFile(new URL(`../data/images/${m.file}`, import.meta.url));

  const up = await sb.storage.from(BUCKET).upload(m.file, body, { contentType: 'image/jpeg', upsert: true });
  if (up.error) throw up.error;
  const { data: pub } = sb.storage.from(BUCKET).getPublicUrl(m.file);

  const { error } = await sb.from('images').insert({
    file_name: m.file,
    storage_path: m.file,
    url: pub.publicUrl,
    width: m.width,
    height: m.height,
    file_size: m.file_size,
    sha256: m.sha256,
    source_url: m.source_url
  });
  if (error) throw error;
  added++;
  console.log(`✓ ${m.file}`);
}
console.log(`Xong. Thêm ${added} hình, bỏ qua ${manifest.length - added} hình đã có.`);
