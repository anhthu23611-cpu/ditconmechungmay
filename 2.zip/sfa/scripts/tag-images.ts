// AI gắn tag cho các hình có tag_status = 'pending'. AI CHỈ được chọn slug trong bảng `tags`.
// Chạy: npm run tag   (đặt TAG_MODEL trong .env nếu muốn đổi model)
import Anthropic from '@anthropic-ai/sdk';
import { createClient } from '@supabase/supabase-js';

const MODEL = process.env.TAG_MODEL ?? 'claude-haiku-5-5';
const MIN_CONFIDENCE = 0.6;
const CONCURRENCY = 4;

const sb = createClient(process.env.PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: { persistSession: false }
});
const ai = new Anthropic();

const { data: tagRows, error: tagErr } = await sb
  .from('tags')
  .select('id, slug, name, tag_groups(name, pick)')
  .order('group_id')
  .order('sort_order');
if (tagErr) throw tagErr;

const idBySlug = new Map(tagRows!.map((t) => [t.slug as string, t.id as number]));
const groupOf = new Map<string, { name: string; pick: string }>();
const byGroup = new Map<string, string[]>();
for (const t of tagRows as any[]) {
  const g = t.tag_groups?.name ?? 'Khác';
  const pick = t.tag_groups?.pick ?? 'many';
  groupOf.set(t.slug, { name: g, pick });
  const label = pick === 'one' ? `${g} [chỉ chọn 1 tag]` : g;
  byGroup.set(label, [...(byGroup.get(label) ?? []), `${t.slug} (${t.name})`]);
}
const vocabulary = [...byGroup].map(([g, items]) => `${g}: ${items.join(', ')}`).join('\n');

const system = `Bạn gắn tag cho kho hình tham khảo của hoạ sĩ.
Chỉ được chọn slug trong danh sách dưới đây, không tự tạo tag mới.
Nhóm ghi [chỉ chọn 1 tag] thì chọn đúng 1 tag phù hợp nhất. Các nhóm còn lại chọn mọi tag thực sự áp dụng được.
Chỉ trả về JSON, không kèm giải thích: {"tags":[{"slug":"...","confidence":0.0}]}

Danh sách tag:
${vocabulary}`;

async function tagOne(img: { id: string; url: string }) {
  try {
    const res = await ai.messages.create({
      model: MODEL,
      max_tokens: 600,
      system,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'url', url: img.url } },
            { type: 'text', text: 'Gắn tag cho hình này.' }
          ]
        }
      ]
    });
    const text = res.content.map((b) => (b.type === 'text' ? b.text : '')).join('');
    const parsed = JSON.parse(text.match(/\{[\s\S]*\}/)?.[0] ?? '{}') as { tags?: { slug: string; confidence?: number }[] };

    const valid = (parsed.tags ?? [])
      .filter((t) => idBySlug.has(t.slug) && (t.confidence ?? 1) >= MIN_CONFIDENCE) // loại slug ngoài danh sách
      .sort((a, b) => (b.confidence ?? 1) - (a.confidence ?? 1));
    // Nhóm pick='one': chỉ giữ tag có độ tin cậy cao nhất
    const seenOne = new Set<string>();
    const kept = valid.filter((t) => {
      const g = groupOf.get(t.slug)!;
      if (g.pick !== 'one') return true;
      if (seenOne.has(g.name)) return false;
      seenOne.add(g.name);
      return true;
    });
    const rows = kept
      .map((t) => ({ image_id: img.id, tag_id: idBySlug.get(t.slug)!, origin: 'ai', confidence: t.confidence ?? null }));

    if (rows.length) {
      const { error } = await sb.from('image_tags').upsert(rows, { onConflict: 'image_id,tag_id', ignoreDuplicates: true });
      if (error) throw error;
    }
    await sb.from('images').update({ tag_status: rows.length ? 'tagged' : 'failed' }).eq('id', img.id);
    console.log(`✓ ${img.id} → ${rows.length} tag`);
  } catch (e) {
    console.error(`✗ ${img.id}`, (e as Error).message);
    await sb.from('images').update({ tag_status: 'failed' }).eq('id', img.id);
  }
}

while (true) {
  const { data: batch, error } = await sb.from('images').select('id, url').eq('tag_status', 'pending').limit(CONCURRENCY * 5);
  if (error) throw error;
  if (!batch?.length) break;
  for (let i = 0; i < batch.length; i += CONCURRENCY) {
    await Promise.all(batch.slice(i, i + CONCURRENCY).map(tagOne));
  }
}
console.log('Xong. Hình lỗi có tag_status = failed, chạy lại bằng cách đặt về pending.');
