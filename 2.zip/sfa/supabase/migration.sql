-- SFA: schema Supabase. Chạy trong SQL Editor (hoặc supabase db push).
-- Nếu đã chạy bản cũ, xoá trước (mất dữ liệu cũ):
--   drop view if exists tag_counts;
--   drop function if exists search_images(text[], integer, integer);
--   drop table if exists tag_reports, image_tags, images, tags, tag_groups cascade;

create table tag_groups (
  id         smallint generated always as identity primary key,
  slug       text unique not null,
  name       text not null,
  pick       text not null default 'many' check (pick in ('one','many')), -- one: mỗi hình chỉ 1 tag trong nhóm
  sort_order smallint not null default 0
);

create table tags (
  id         integer generated always as identity primary key,
  group_id   smallint not null references tag_groups(id) on delete cascade,
  slug       text unique not null,
  name       text not null,
  aliases    text[] not null default '{}',   -- từ đồng nghĩa dùng cho lọc/gợi ý
  swatch     text,                           -- mã màu hex, chỉ dùng cho nhóm Màu sắc
  sort_order smallint not null default 0
);

create table images (
  id           uuid primary key default gen_random_uuid(),
  file_name    text unique,                    -- tên file gốc, ví dụ 001.jpg
  storage_path text unique,                    -- đường dẫn trong bucket 'images' (null nếu ảnh chỉ là link ngoài)
  url          text not null unique,           -- link công khai để hiển thị (Storage hoặc link ngoài)
  source_label text not null default 'Nguồn: Pinterest',
  source_url   text,
  width        integer,
  height       integer,
  file_size    integer,
  sha256       text unique,                    -- chống nhập trùng cùng một ảnh
  tag_status   text not null default 'pending'
               check (tag_status in ('pending','tagged','failed','reviewed')),
  created_at   timestamptz not null default now()
);

-- Giới hạn thử nghiệm: tối đa 100 hình. Muốn bỏ giới hạn:
--   drop trigger images_limit on images;
create function enforce_image_limit() returns trigger
language plpgsql as $f$
begin
  if (select count(*) from images) >= 100 then
    raise exception 'Đã đủ 100 hình (giới hạn thử nghiệm).';
  end if;
  return new;
end $f$;
create trigger images_limit before insert on images
  for each row execute function enforce_image_limit();

-- Nơi lưu file ảnh. Bucket công khai: ai cũng xem được, chỉ service_role mới được tải lên.
insert into storage.buckets (id, name, public)
values ('images', 'images', true)
on conflict (id) do nothing;

create table image_tags (
  image_id   uuid    not null references images(id) on delete cascade,
  tag_id     integer not null references tags(id)   on delete cascade,
  origin     text    not null default 'ai' check (origin in ('ai','manual')),
  confidence real,
  primary key (image_id, tag_id)
);
create index image_tags_tag_idx on image_tags (tag_id, image_id);

create table tag_reports (
  id         bigint generated always as identity primary key,
  image_id   uuid not null references images(id) on delete cascade,
  tag_id     integer references tags(id) on delete set null,  -- null = lỗi chung / thiếu tag
  note       text check (char_length(note) <= 500),
  status     text not null default 'open' check (status in ('open','resolved','rejected')),
  created_at timestamptz not null default now()
);
create index tag_reports_open_idx on tag_reports (status, created_at desc);

-- Số hình theo tag, để giao diện hiển thị và làm mờ tag chưa có hình
create view tag_counts with (security_invoker = true) as
select t.id as tag_id, count(it.image_id)::int as image_count
from tags t left join image_tags it on it.tag_id = t.id
group by t.id;

-- Tìm hình có đủ TẤT CẢ tag được chọn. Mảng rỗng = duyệt tất cả (mới nhất trước).
create or replace function search_images(
  tag_slugs   text[]  default '{}',
  page_limit  integer default 24,
  page_offset integer default 0
)
returns table (
  id uuid, url text, source_label text, source_url text,
  width integer, height integer, tags jsonb, total_count bigint
)
language sql stable
set search_path = public
as $$
  with wanted as (
    select t.id from tags t where t.slug = any(tag_slugs)
  ),
  matched as (
    select i.id from images i where cardinality(tag_slugs) = 0
    union all
    select it.image_id from image_tags it
    join wanted w on w.id = it.tag_id
    where cardinality(tag_slugs) > 0
    group by it.image_id
    having count(*) = cardinality(tag_slugs)
  )
  select i.id, i.url, i.source_label, i.source_url, i.width, i.height,
         coalesce((
           select jsonb_agg(jsonb_build_object('id', t.id, 'slug', t.slug, 'name', t.name)
                            order by t.group_id, t.sort_order)
           from image_tags it join tags t on t.id = it.tag_id
           where it.image_id = i.id
         ), '[]'::jsonb) as tags,
         count(*) over () as total_count
  from matched m join images i on i.id = m.id
  order by i.created_at desc, i.id
  limit page_limit offset page_offset;
$$;

-- Row Level Security: web chỉ được đọc, và chỉ được gửi báo cáo tag sai.
alter table tag_groups  enable row level security;
alter table tags        enable row level security;
alter table images      enable row level security;
alter table image_tags  enable row level security;
alter table tag_reports enable row level security;

create policy "public read" on tag_groups for select to anon, authenticated using (true);
create policy "public read" on tags       for select to anon, authenticated using (true);
create policy "public read" on images     for select to anon, authenticated using (true);
create policy "public read" on image_tags for select to anon, authenticated using (true);
create policy "public report" on tag_reports for insert to anon, authenticated
  with check (status = 'open');
-- Ghi dữ liệu (ảnh, tag AI) dùng service_role key trong scripts/, bỏ qua RLS.
