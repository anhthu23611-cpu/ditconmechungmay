-- 5 nhóm, 24 tag chuẩn. AI chỉ được chọn trong danh sách này.
-- Nếu đã chạy seed cũ, xoá trước:  truncate tag_groups restart identity cascade;

insert into tag_groups (slug, name, pick, sort_order) values
  ('chu-de',    'Chủ đề',    'many', 1),
  ('chat-lieu', 'Chất liệu', 'one',  2),
  ('mau-sac',   'Màu sắc',   'one',  3),
  ('goc-nhin',  'Góc nhìn',  'one',  4),
  ('dia-diem',  'Địa điểm',  'many', 5);

insert into tags (group_id, slug, name, aliases, swatch, sort_order)
select g.id, v.slug, v.name, v.aliases, v.swatch, v.ord
from (values
  -- Chủ đề (6)
  ('chu-de','phong-canh','Phong cảnh',array['landscape','cảnh vật'],null,1),
  ('chu-de','chan-dung','Chân dung',array['portrait','khuôn mặt'],null,2),
  ('chu-de','kien-truc','Kiến trúc',array['nhà cửa','building'],null,3),
  ('chu-de','dong-vat','Động vật',array['animal','thú'],null,4),
  ('chu-de','tinh-vat','Tĩnh vật',array['still life'],null,5),
  ('chu-de','hoa-tiet','Hoạ tiết',array['pattern','họa tiết','texture'],null,6),

  -- Chất liệu (5)
  ('chat-lieu','son-dau','Sơn dầu',array['oil painting','oil'],null,1),
  ('chat-lieu','mau-nuoc','Màu nước',array['watercolor'],null,2),
  ('chat-lieu','chi','Chì',array['pencil','bút chì','than'],null,3),
  ('chat-lieu','anh-chup','Ảnh chụp',array['photo','photograph'],null,4),
  ('chat-lieu','ky-thuat-so','Kỹ thuật số (AI)',array['digital','AI','vẽ máy'],null,5),

  -- Màu sắc (4). swatch là giá trị CSS background (màu hoặc gradient)
  ('mau-sac','tong-am','Tông ấm',array['warm','đỏ','cam','vàng'],'#D9822B',1),
  ('mau-sac','tong-lanh','Tông lạnh',array['cool','xanh','tím'],'#4A86B8',2),
  ('mau-sac','trang-den','Trắng đen',array['đen trắng','monochrome','đơn sắc'],'linear-gradient(90deg,#fff 50%,#222 50%)',3),
  ('mau-sac','da-sac','Đa sắc',array['nhiều màu','colorful'],'conic-gradient(#C8372D,#F2C230,#4F9D5D,#2F6FB5,#7A4FA3,#C8372D)',4),

  -- Góc nhìn (4)
  ('goc-nhin','tu-tren-cao','Từ trên cao',array['top view','bird eye','từ trên xuống'],null,1),
  ('goc-nhin','ngang','Ngang',array['eye level','ngang tầm mắt','chính diện'],null,2),
  ('goc-nhin','can-canh','Cận cảnh',array['close up'],null,3),
  ('goc-nhin','tu-xa','Từ xa',array['wide','toàn cảnh','panorama'],null,4),

  -- Địa điểm (5)
  ('dia-diem','thanh-pho','Thành phố',array['city','đô thị','phố'],null,1),
  ('dia-diem','thon-que','Thôn quê',array['nông thôn','làng quê','đồng quê'],null,2),
  ('dia-diem','canh-dong','Cánh đồng',array['đồng ruộng','field','ruộng lúa'],null,3),
  ('dia-diem','bien','Biển',array['sea','beach','bãi biển'],null,4),
  ('dia-diem','truong-hoc','Trường học',array['school','lớp học','sân trường'],null,5)
) as v(group_slug, slug, name, aliases, swatch, ord)
join tag_groups g on g.slug = v.group_slug;
